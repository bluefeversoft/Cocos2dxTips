//
//  CMyTree.h
//  Cocos2dxTips
//
//  Created by ScreenCast on 08/04/14.
//
//

#ifndef __Cocos2dxTips__CMyTree__
#define __Cocos2dxTips__CMyTree__

#include "cocos2d.h"

class CMyTree : public cocos2d::CCSprite {

private:
	int _numClicks;
	float _timeSinceLast;
	
public:
	static CMyTree *createTree(const char *FileName);
	
	void ResetTime() { _timeSinceLast = 0; }
	void ResetClicks() { _numClicks = 0; }
	void LogInfo() { CCLOG("NumClicks:%d TimeSinceLast:%.1f",_numClicks, _timeSinceLast); }
	void UpdateTime(float dt) { _timeSinceLast += dt; }
	void IncClicks() { _numClicks++; }
	
};

#endif /* defined(__Cocos2dxTips__CMyTree__) */
