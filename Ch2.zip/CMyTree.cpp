//
//  CMyTree.cpp
//  Cocos2dxTips
//
//  Created by ScreenCast on 08/04/14.
//
//

#include "CMyTree.h"

CMyTree *CMyTree::createTree(const char *FileName) {
	CMyTree *sprite = new CMyTree();
	if(sprite && sprite->initWithFile(FileName)) {
		sprite->autorelease();
		sprite->ResetTime();
		sprite->ResetClicks();
		return sprite;
	}
	CC_SAFE_DELETE(sprite);
	return NULL;
}
