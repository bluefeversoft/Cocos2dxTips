#include "HelloWorldScene.h"
#include "CMyTree.h"

USING_NS_CC;

CCScene* HelloWorld::scene()
{
    // 'scene' is an autorelease object
    CCScene *scene = CCScene::create();
    
    // 'layer' is an autorelease object
    HelloWorld *layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !CCLayer::init() )
    {
        return false;
    }
    
    CCSize visibleSize = CCDirector::sharedDirector()->getVisibleSize();
    CCPoint origin = CCDirector::sharedDirector()->getVisibleOrigin();
	
	_tree = CMyTree::createTree("Tree-HD.png");
	_tree->setPosition(ccp(visibleSize.width / 2, visibleSize.height / 2));
	this->addChild(_tree);
	
	this->schedule(schedule_selector(HelloWorld::GameUpdate));
	this->setTouchEnabled(true);
	
    return true;
}

void HelloWorld::GameUpdate(float dt) {
	_gameTime += dt;
	_tree->UpdateTime(dt);
	// CCLOG("_gameTime:%0.2f",_gameTime);
}

void HelloWorld::ccTouchesBegan(cocos2d::CCSet *pTouch, cocos2d::CCEvent *event) {
	CCSetIterator i;
	CCTouch *touch;
	CCPoint tap;
	
	for(i = pTouch->begin(); i != pTouch->end(); ++i) {
		touch = (CCTouch*)(*i);
		if(touch) {
			tap = touch->getLocation();
			_tree->IncClicks();
			_tree->LogInfo();
			_tree->ResetTime();
			_tree->setPosition(ccp(tap.x, tap.y));
		}
	}
	
}

void HelloWorld::ccTouchesMoved(cocos2d::CCSet *pTouch, cocos2d::CCEvent *event){
	
}

void HelloWorld::ccTouchesEnded(cocos2d::CCSet *pTouch, cocos2d::CCEvent *event){
	
}



















